package cn.tydy.dao.role;

import cn.tydy.pojo.Role;

import java.util.List;

public interface RoleMapper {
    public List<Role> getRoleList()throws Exception;
    public Role getRoleById(Integer id)throws Exception;
}
