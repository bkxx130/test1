package cn.tydy.convert;

import org.springframework.core.convert.converter.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * 自定义转换器
 */
public class StringToDateConverter implements Converter<String, Date> {



    List<SimpleDateFormat>sdfs= Arrays.asList(
            new SimpleDateFormat("yyyy-MM-dd"),
            new SimpleDateFormat("yyyy/MM/dd"),
            new SimpleDateFormat("yyyy.MM.dd"),
            new SimpleDateFormat("yy-MM-dd"),
            new SimpleDateFormat("yy/MM/dd"),
            new SimpleDateFormat("yy.MM.dd")
    );

    @Override
    public Date convert(String s) {
        Date date=null;
        for (SimpleDateFormat sdf:sdfs) {
            try {
                date=sdf.parse(s);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return date;
    }
}
