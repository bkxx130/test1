package cn.tydy.service.user;

import cn.tydy.dao.user.UserMapper;
import cn.tydy.pojo.User;

import cn.tydy.service.user.UserService;
import cn.tydy.vo.UserVo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Resource(name="userMapper")
    private UserMapper userMapper;
    /*public UserMapper getUserMapper() {
        return userMapper;
    }
    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }*/

    //给该方法添加事务（遇到Exception时回滚）
    /*@Transactional(rollbackFor = Exception.class )*/
    @Override
    public int addUser(List<User> users) throws Exception {
        int result=0;
        for (int i=0;i<users.size();i++) {
            result+=userMapper.addUser(users.get(i));
            if(i==1){
                throw new Exception("现在是第"+i+"条数据");
            }
        }
        return result;
    }

    @Override
    public int addUser(User user) throws Exception {
        return userMapper.addUser(user);
    }

    @Override
    public User getLoginUser(String userCode) throws Exception {
        return userMapper.getLoginUser(userCode);
    }

    @Override
    public List<User> getUserList(UserVo userVo) throws Exception {
        return userMapper.getUserList(userVo);
    }

    @Override
    public int getUserCount(String userName, int userRole) throws Exception {
        return userMapper.getUserCount(userName,userRole);
    }

    @Override
    public int deleteUserById(Integer delId) throws Exception {
        return userMapper.deleteUserById(delId);
    }

    @Override
    public User getUserById(Integer id) throws Exception {
        return userMapper.getUserById(id);
    }

    @Override
    public int modify(User user) throws Exception {
        return userMapper.modify(user);
    }

    @Override
    public int updatePwd(int id, String pwd) throws Exception {
        return userMapper.updatePwd(id,pwd);
    }

    @Override
    public User login(String userCode, String userPassword) {
        return userMapper.login(userCode,userPassword);
    }

    @Override
    public boolean checkUserCode(String userCode) {

        if(userMapper.checkUserCode(userCode)>0){
            //已经存在
            return true;
        }else{
            //不存在，可以创建
            return false;
        }

    }
}
