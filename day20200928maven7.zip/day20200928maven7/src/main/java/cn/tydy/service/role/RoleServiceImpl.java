package cn.tydy.service.role;

import cn.tydy.dao.role.RoleMapper;
import cn.tydy.pojo.Role;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("roleService")
public class RoleServiceImpl implements RoleService {

    @Resource(name="roleMapper")
    private RoleMapper roleMapper;

  /*  public RoleMapper getRoleMapper() {
        return roleMapper;
    }

    public void setRoleMapper(RoleMapper roleMapper) {
        this.roleMapper = roleMapper;
    }*/

    @Override
    public List<Role> getRoleList() throws Exception {
        return roleMapper.getRoleList();
    }

    @Override
    public Role getRoleById(Integer id) throws Exception {
        return roleMapper.getRoleById(id);
    }
}
