package cn.tydy.service.role;

import cn.tydy.pojo.Role;

import java.util.List;

public interface RoleService {
    public List<Role> getRoleList()throws Exception;
    public Role getRoleById(Integer id)throws Exception;
}
