package cn.tydy.service.provider;

import cn.tydy.dao.provider.ProvMapper;
import cn.tydy.pojo.Provider;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;


@Service("providerService")
public class ProviderServiceImpl implements ProviderService {

    @Resource(name="provMapper")
    private ProvMapper provMapper;
   /* public ProvMapper getProvMapper() {
        return provMapper;
    }
    public void setProvMapper(ProvMapper provMapper) {
        this.provMapper = provMapper;
    }*/

    @Override
    public int addProvider(Provider provider) throws Exception {
        return provMapper.addProvider(provider);
    }

    @Override
    public List<Provider> getProviderList(String proName, String proCode) throws Exception {
        return provMapper.getProviderList(proName,proCode);
    }

    @Override
    public int deleteProviderById(Integer delId) throws Exception {
        return provMapper.deleteProviderById(delId);
    }

    @Override
    public Provider getProviderById(Integer id) throws Exception {
        return provMapper.getProviderById(id);
    }

    @Override
    public int modify(Provider provider) throws Exception {
        return provMapper.modify(provider);
    }
}
