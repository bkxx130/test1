package cn.tydy.service.bill;

import cn.tydy.dao.bill.BillMapper;
import cn.tydy.dao.user.UserMapper;
import cn.tydy.pojo.Bill;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

//给BillServiceImpl加注释
@Service("billService")
public class BillServiceImpl implements BillService {

    //依赖注入
    @Resource(name="billMapper")
    private BillMapper billMapper;
    /*public BillMapper getBillMapper() {
        return billMapper;
    }
    public void setBillMapper(BillMapper billMapper) {
        this.billMapper = billMapper;
    }*/

    @Resource(name="userMapper")
    private UserMapper userMapper;


    @Override
    public int addBill(Bill bill, Integer userId) throws Exception {

        bill.setCreatedBy(userId);
        return billMapper.addBill(bill);
    }

    @Override
    public List<Bill> getBillList(Bill bill) throws Exception {
        return billMapper.getBillList(bill);
    }

    @Override
    public int deleteBillById(Integer delId) throws Exception {
        return billMapper.deleteBillById(delId);
    }

    @Override
    public Bill getBillById(Integer id) throws Exception {
        return billMapper.getBillById(id);
    }

    @Override
    public int modify(Bill bill) throws Exception {
        return billMapper.modify(bill);
    }

    @Override
    public int getBillCountByProviderId(Integer providerId) throws Exception {
        return billMapper.getBillCountByProviderId(providerId);
    }
}
