package cn.tydy.vo;

public class UserVo {
    private  Integer userRole;//用户角色
    private  String userName;//用户姓名
    private  Integer startIndex;//
    private  Integer pageSize;//本页显示的数量
    public void setUserRole(Integer userRole) {
        this.userRole = userRole;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public void setStartIndex(Integer startIndex) {
        this.startIndex = startIndex;
    }
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
