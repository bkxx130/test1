package cn.tydy.controller;


import cn.tydy.pojo.Bill;
import cn.tydy.pojo.Provider;
import cn.tydy.pojo.User;
import cn.tydy.service.bill.BillServiceImpl;
import cn.tydy.service.provider.ProviderServiceImpl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping(value = "/bill")
public class BillController {

    @Resource(name="billService")
    public BillServiceImpl billService;

    @Resource(name = "providerService")
    public ProviderServiceImpl providerService;

    @RequestMapping(value = "billList.html")
    public String toBillList(String queryProductName,Integer queryProviderId,
                             Integer queryIsPayment,
                             HttpServletRequest request) throws Exception {
        //查询所有的订单
        Bill bill=new Bill();
        bill.setProductName(queryProductName);//商品名称
        bill.setIsPayment(queryIsPayment);//是否支付
        bill.setProviderId(queryProviderId);//供应商id
        List<Bill> bills= billService.getBillList(bill);
        System.out.println("订单数量："+bills.size());
        //所有的订单数
        request.setAttribute("bills",bills);
        //所有的供应商
        List<Provider> providers= providerService.getProviderList("","");
        System.out.println("供应商数量："+providers.size());
        request.setAttribute("providers",providers);
        return "billList";



    }



    /**
     * 跳到添加订单页面
     */
    @RequestMapping(value = "billadd.html")
    public String toBillAdd(HttpServletRequest request) throws Exception {
        //所有的供应商
        List<Provider> providers= providerService.getProviderList("","");
        System.out.println("供应商数量："+providers.size());
        request.setAttribute("providers",providers);
        return "billadd";
    }
    /**
     * 添加信息后判断
     */
    @RequestMapping(value = "billadd.do")
    public String BillAdd(Bill bill, HttpServletRequest request) throws Exception {
        User user = (User) request.getSession().getAttribute("user");
        if(billService.addBill(bill,user.getId())>0){
            //添加成功
            return "redirect:/bill/billList.html";
        }else{
            //添加失败
            request.setAttribute("bill",bill);
            return "forward:/bill/billadd.html";
        }
    }
    /**
     * 删除订单
     */
    @RequestMapping("delBill.do/{id}")
    public String delBill(@PathVariable Integer id) throws Exception {
        billService.deleteBillById(id);
        return "redirect:/bill/billList.html";
    }


    /**
     * 跳修改页面
     */
    @RequestMapping("updbillmodify.html/{id}")
    public String toUpdBillmodify(@PathVariable Integer id, HttpServletRequest request) throws Exception {
        Bill bill=billService.getBillById(id);
        request.setAttribute("bill",bill);
        return "billmodify";
    }
    /**
     * 修改订单后判断
     */
    @RequestMapping("updbillmodify.do")
    public String updBillmodify(Bill bill, HttpServletRequest request) throws Exception {
        System.out.println("bill修改后："+bill);
        if(billService.modify(bill)>0){
            System.out.println("修改成功！");
            //修改成功
            return "redirect:/bill/billList.html";
        }else{
            //修改失败
            System.out.println("修改失败！");
            request.setAttribute("bill",bill);

            return "billmodify";
        }
    }
    /**
     * 订单详情
     */
    @RequestMapping("billdetail.html/{id}")
    public String toBilldetail(@PathVariable Integer id, HttpServletRequest request) throws Exception {
        Bill bill=billService.getBillById(id);
        request.setAttribute("bill",bill);

        return "billdetail";
    }

}
