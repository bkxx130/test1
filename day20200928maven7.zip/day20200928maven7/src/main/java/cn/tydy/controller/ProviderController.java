package cn.tydy.controller;


import cn.tydy.pojo.Provider;
import cn.tydy.service.provider.ProviderServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@RequestMapping(value = "provider")
public class ProviderController {


    @Resource(name = "providerService")
    private ProviderServiceImpl providerService;


    @RequestMapping(value = "providerList.html")
    public String toproviderList(String queryProCode,String queryProName,
                                 HttpServletRequest request) throws Exception {
        //查全部供应商
        List<Provider> providers=providerService.getProviderList(queryProName,queryProCode);

        /*if(providers.size()>0){
            throw new Exception("供应商数太多了！");
        }*/
        request.setAttribute("providers",providers);

        return "providerList";
    }

    /**
     * 跳添加页面
     * @return
     */
    @RequestMapping(value = "provideradd.html")
    public String toProvideradd(){
        return "provideradd";
    }

    /**
     * 添加后判断跳转页面
     * @param provider
     * @param request
     * @return
     */

    @RequestMapping(value = "provider.do")
    public String providerAdd(Provider provider, HttpServletRequest request) throws Exception {
        if(providerService.addProvider(provider)>0){
            //成功
            return "redirect:/provider/providerList.html";
        }else{
            //失败
            request.setAttribute("provider",provider);
            return "/provider/provideradd";
        }
    }

    /**
     * 删除
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "delprovider.do/{id}")
    public String delprovider(@PathVariable Integer id) throws Exception {
        providerService.deleteProviderById(id);

        return "redirect:/provider/providerList.html";
    }

    /**
     * 跳修改页面
     * @param id
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping("providermodify.html/{id}")
    public String toProModify(@PathVariable Integer id, HttpServletRequest request) throws Exception {
        Provider provider=providerService.getProviderById(id);
        System.out.println("修改前的provider："+provider);
        request.setAttribute("provider",provider);
        return "providermodify";
    }

    @RequestMapping("providermodify.do")
    public String providermodify(Provider provider, HttpServletRequest request) throws Exception {

        System.out.println("修改后的provider："+provider);
        if(providerService.modify(provider)>0){
            //成功

            return "redirect:/provider/providerList.html";

        }else{
            //失败
            request.setAttribute("provider",provider);
            return "providermodify";
        }
    }

    @RequestMapping("providerdetail.html/{id}")
    public String toProviderdetail(@PathVariable Integer id, HttpServletRequest request) throws Exception {
        Provider provider=providerService.getProviderById(id);
        request.setAttribute("provider",provider);
        return "providerdetail";
    }

}

