package cn.tydy.controller;


import cn.tydy.pojo.User;
import cn.tydy.service.role.RoleServiceImpl;
import cn.tydy.service.user.UserServiceImpl;
import cn.tydy.tools.Dto;
import cn.tydy.vo.UserVo;
import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping(value="/user")
public class UserController {

    @Resource(name="userService")
    public UserServiceImpl userService;

    @Resource(name="roleService")
    public RoleServiceImpl roleService;

    @RequestMapping(value = "login.do",method = RequestMethod.POST)
    public String login( String userCode, String userPassword, HttpServletRequest request) throws LoginException {
        System.out.println("输出userCode："+userCode+"输出pwd："+userPassword);

        User user=userService.login(userCode,userPassword);
        System.out.println(user);
        if(user==null){
            //跳登录页面Login.jsp,session带对象
            //request.setAttribute("msg","用户名或密码错误");
            throw new LoginException("有一个东西错了！");
            // return "Login";
        }else{
            //跳显示页面billList.jsp
            HttpSession session=request.getSession();
            session.setAttribute("user",user);
            System.out.println("------------重定向到billList.html");
            //重定向跳转到billList.jsp页面
            return "redirect:/bill/billList.html";
        }

    }



    //自定义异常 异常处理机制
    @ExceptionHandler(value = LoginException.class)
    public String handlerException(LoginException e, HttpServletRequest request){
        request.setAttribute("e",e);
        return "Login";
    }

    @RequestMapping(value = "logout.do")
    public String logout(HttpSession session){
        //清空所有的session
        session.invalidate();
        //清空后跳转到登录页面
        return "Login";
    }



    @RequestMapping(value="userList.html")
    public String getUserList() throws Exception {

        return "userList";
    }

    @ResponseBody
    @RequestMapping(value="userList.do")
    public String getUserList(String queryname,Integer queryUserRole) throws Exception {
        UserVo uservo=new UserVo();
        uservo.setUserName(queryname);
        uservo.setUserRole(queryUserRole);
        uservo.setStartIndex(1);
        uservo.setPageSize(20);
        //查所有用户
        List<User> users=userService.getUserList(uservo);
        Dto dto=new Dto();
        dto.setCode("200");
        dto.setData(users);

        String json= JSON.toJSONString(dto);
        return json;
    }

    /*@RequestMapping(value="userList.html")
    public String getUserList(String queryname,Integer queryUserRole
            ,HttpServletRequest request) throws Exception {
        UserVo uservo=new UserVo();
        uservo.setUserName(queryname);
        uservo.setUserRole(queryUserRole);
        uservo.setStartIndex(1);
        uservo.setPageSize(20);
        //查所有用户
        List<User> users=userService.getUserList(uservo);


        request.setAttribute("users",users);
        return "userList";
    }*/

    @RequestMapping(value = "pwdmodify.html")
    public String toUsermodify(){
        return "pwdmodify";
    }

    @RequestMapping(value = "pwdmodify.do")
    public String modelAndView(String oldpassword, String newpassword,
                               String rnewpassword, HttpSession session,
                               HttpServletRequest request) throws Exception {
        User user=(User)session.getAttribute("user");
        System.out.println("用户密码:"+user.getUserPassword());
        System.out.println("旧密码:"+oldpassword);
        if(!user.getUserPassword().equals(oldpassword)){
            request.setAttribute("msg","旧密码输入错误！");
            return "pwdmodify";
        }
        System.out.println("用户id："+user.getId());
        System.out.println("旧密码："+oldpassword+"新密码："+newpassword+"重复新密码："+rnewpassword);

        int result=userService.updatePwd(user.getId(),newpassword);
        if(result>0){
            //修改成功
            return "Login";
        }
        return "pwdmodify";
    }


    /**
     * 跳用户新增页面
     */
    @RequestMapping(value = "useradd.html")
    public String toUserAdd(){

        return "useradd";
    }

    List<String> extNames=new ArrayList<>();
    /**
     * 添加之后跳转
     */
    @RequestMapping(value = "useradd.do",method = RequestMethod.POST)
    public String useradd(User user, MultipartFile photo, HttpServletRequest request) throws Exception {
        System.out.println("进来useradd.do方法了！");
        extNames.add(".png");
        extNames.add(".jpg");
        extNames.add(".gif");

        //验证图片是否传入
        if (photo!=null){
            //获取文件名
            String oldFileName=photo.getOriginalFilename();
            //获取文件后缀名
            String hz=oldFileName.substring(oldFileName.lastIndexOf("."));
            System.out.println(hz);
            //验证是否是指定的图片格式
            if (extNames.contains(hz)){
                //验证文件大小
                if (photo.getSize()<=5000000){
                    //获取文件需要存在服务器的地址
                    String newFilePath=request.getServletContext().getInitParameter("imagepath");
                    //设置新文件的名称
                    String newFileName= UUID.randomUUID().toString()+hz;
                    //根据地址和名称创建文件对象File
                    File file=new File(newFilePath+newFileName);
                    //判断对象是否存在，如果不存在创建(制作路径)
                    if(!file.exists()){
                        file.mkdirs();
                    }
                    //将传入文件内容复制到新文件中
                    try {
                        photo.transferTo(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    //配置图片的虚拟路径，保存到user对象，传入service，进行保存
                    String relationPath="/images/"+newFileName;

                    System.out.println("头像路径："+relationPath);

                }else{
                    System.out.println("文件太大了");
                }

            }else{
                System.out.println("文件格式不对");
            }

        }



        int result=userService.addUser(user);
        if(result>0){
            //新增成功跳userList.jsp页面
            return "redirect:/user/userList.html";
        }else{
            //失败跳useradd.jsp页面
            request.setAttribute("user",user);
            return "forward:/user/useradd.html";
        }
    }

    /**
     * 使用restFull风格，通过id删除用户
     * @param id
     * @return
     */
    @RequestMapping("delUser.do/{id}")
    public String delUser(@PathVariable Integer id) throws Exception {
        userService.deleteUserById(id);
        //不管成功失败都跳转到userList.jsp
        return "redirect:/user/userList.html";
    }

    /**
     * 跳修改页面
     * @param id
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping("modifyUser.html/{id}")
    public String toUsermodify(@PathVariable Integer id, HttpServletRequest request) throws Exception {
        User user=userService.getUserById(id);
        System.out.println("要修改的用户信息："+user);
        request.setAttribute("user",user);
        return "usermodify";
    }

    /**
     * 修改
     * @param user
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping("usermodify.do")
    public String usermodify(User user, HttpServletRequest request) throws Exception {
        System.out.println("修改后的user："+user);

        int result=userService.modify(user);
        if(result>0){
            //跳查询页面
            return "redirect:/user/userList.html";
        }else{
            //带数据跳修改页面
            request.setAttribute("user",user);
            return "usermodify";
        }
    }

    @RequestMapping("userdetail.html/{id}")
    public String toUserdetail(@PathVariable Integer id, HttpServletRequest request) throws Exception {
        User user=userService.getUserById(id);


        request.setAttribute("user",user);

        return "userdetail";
    }

    //解决json返回中文乱码问题方法一：produces = {"application/json;charset=UTF-8"}
    //方法二为一劳永逸方法（在springmvc-servlet.xml配置文件中配置）
    @RequestMapping(value = "checkUserCode.do")
    @ResponseBody //让接口返回的是json格式的数据
    public String checkUserCode(String userCode){
        Dto dto=new Dto();
        if(userService.checkUserCode(userCode)){
            //已经存在，不能创建
            dto.setCode("1000");
            dto.setMessage("userCode exist(存在)");

        }else{
            //可以创建
            dto.setCode("200");
            dto.setMessage("userCode not exist(不存在)");
        }
        String json= JSON.toJSONString(dto);
        return json;
    }
}
